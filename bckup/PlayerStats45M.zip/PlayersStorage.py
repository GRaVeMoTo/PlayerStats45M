# Author: GRaVE
#
import datetime
from CfxServer import CfxPlayer

class PlyerData:
    def __init__(self, name: str, id: str, ping: int ):
        self.id = id
        self.name = name
        self.lastping = ping
        self.loginTime = datetime.now()
        self.logoffTime = None

class PlayersStorage:
    def __init__(self):
        self.Players : dict[str, PlyerData] = {}

    def UpdatePlayersFromServer(self, players: list[CfxPlayer]) -> None:
        if players is None:
            return
        
        for pd in players:
           if pd.id != '-1':
                    if self.Players[serverID] is None:
                        self.Players[serverID] = {}
                    
